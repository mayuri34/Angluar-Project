import { Component, OnInit } from '@angular/core';
import {User} from '../shared/models/user.model';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.scss']
})
export class UserFormComponent implements OnInit {
  submitted = false;
  model = new User("Mark", "Nguyen", 100);
  constructor() { }

  ngOnInit() {
  }
  onSubmit(e) { 
    this.submitted = true; 
  }


}

