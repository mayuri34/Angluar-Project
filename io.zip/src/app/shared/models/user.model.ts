export class User {
    constructor(
        private firstName: string,
        private lastName: string,
        private age: number,
    ) {}

    getFullName() {
        return this.firstName + " " + this.lastName;
    }
    getAge() {
        return this.age;
    }
}